export class Ci_vettore {
    INDIRIZZO: string;
    WGS84_X: number;
    WGS84_Y: number;
    CLASSE_ENE: string;
    EP_H_ND: number;
    CI_VETTORE: string;
    FOGLIO: string;
    SEZ: number;
}
